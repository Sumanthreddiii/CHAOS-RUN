// ===== CHAOS RUN settings =====
// Paste your Google Apps Script web-app link between the quote marks.
// It looks like: https://script.google.com/macros/s/XXXXXXXX/exec
var CHAOS_COLLECT_URL = '';
